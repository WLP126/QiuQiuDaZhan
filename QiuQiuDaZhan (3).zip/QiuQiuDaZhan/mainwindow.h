#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QMouseEvent>
#include <QVector>
#include <QColor>
#include <QPushButton>
#include <QPixmap>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

struct Ball {
    int x, y;
    int radius;
    QColor color;
    int speedX, speedY;
    int hp;
    QPixmap skin; // 贴图皮肤
};

struct Star {
    int x, y;
    int radius;
    int speedY;
};

struct Item {
    int x, y;
    int radius;
    enum Type { Speed, Shield, Heal } type;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;

private slots:
    void gameUpdate();
    void startGame();
    void updateTimer();

private:
    Ui::MainWindow *ui;

    // 游戏状态
    bool inGame;
    const int MAP_WIDTH = 4000;
    const int MAP_HEIGHT = 4000;
    const int MAX_HP = 100;
    const int GAME_DURATION = 180; // 3分钟

    Ball player;
    int offsetX, offsetY;
    int hp;
    int score;
    int remainingTime;

    QVector<Ball> foods;
    QVector<Ball> enemies;
    QVector<Star> stars;
    QVector<Item> items;

    QTimer *timer;
    QTimer *countdownTimer;
    QPushButton *startButton;

    // 玩家皮肤选择
    int playerSkinIndex; // -1 表示未选择
    QStringList allSkins; // 9 个皮肤路径
    QVector<QPushButton*> skinButtons; // 开机皮肤按钮

    // 私有方法
    void initGame();
    void spawnFood(int count = 1);
    void spawnEnemies(int count = 1);
    void spawnStars();
    void spawnItems();
    void moveEnemies();
    void moveStars();
    void checkCollisions();
    void gameOver(bool win = false);
    void applyItemEffect(Item::Type type);
};

#endif // MAINWINDOW_H
