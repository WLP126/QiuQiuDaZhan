#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QRandomGenerator>
#include <cmath>
#include <QFont>
#include <QMessageBox>
#include <QMouseEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(900,700);
    inGame = false;
    this->setMouseTracking(true);

    // ---------------- 初始化皮肤 ----------------
    allSkins = QStringList()
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin1.jpg"
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin2.jpg"
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin3.jpg"
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin4.jpg"
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin5.jpg"
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin6.jpg"
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin7.jpg"
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin8.jpg"
        << "C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/skin9.jpg";
    playerSkinIndex = -1;

    // ---------------- 创建皮肤按钮 ----------------
    for(int i=0;i<allSkins.size();i++){
        QPushButton *btn = new QPushButton(this);
        btn->setIcon(QIcon(allSkins[i]));
        btn->setIconSize(QSize(80,80));
        btn->setGeometry(50 + (i%3)*100, 300 + (i/3)*100, 80, 80);
        skinButtons.push_back(btn);
        connect(btn, &QPushButton::clicked, [=](){
            playerSkinIndex = i;
            player.skin = QPixmap(allSkins[i]);
            for(QPushButton* b : skinButtons) b->hide();
            startButton->show();
        });
        btn->show();
    }

    // ---------------- 开始按钮 ----------------
    startButton = new QPushButton("开始游戏", this);
    startButton->setGeometry(350, 550, 200, 100);
    startButton->setStyleSheet("font-size:24px; background-color: #00AAFF; color: white; border-radius: 10px;");
    connect(startButton, &QPushButton::clicked, this, &MainWindow::startGame);
    startButton->hide();

    // ---------------- 定时器 ----------------
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::gameUpdate);
    timer->start(30);

    countdownTimer = new QTimer(this);
    connect(countdownTimer, &QTimer::timeout, this, &MainWindow::updateTimer);

    // ---------------- 星星 ----------------
    spawnStars();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ---------------- startGame ----------------
void MainWindow::startGame()
{
    inGame = true;           // 游戏状态置为进行中
    initGame();              // 初始化玩家、敌人、食物、道具
    startButton->hide();     // 隐藏开始按钮
    countdownTimer->start(1000); // 启动每秒倒计时
}

// ---------------- paintEvent ----------------
void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    // ---------------- 开机界面绘制 ----------------
    if(!inGame){
        // 背景
        QPixmap bg("C:/Users/w1357/Desktop/Qt/QiuQiuDaZhan/images/start_bg.jpg");
        if(!bg.isNull()) painter.drawPixmap(0,0,width(),height(),bg);
        else {
            QLinearGradient gradient(0,0,0,height());
            gradient.setColorAt(0,QColor(5,5,50));
            gradient.setColorAt(1,QColor(0,0,20));
            painter.fillRect(rect(), gradient);
        }

        // 星星粒子
        painter.setPen(Qt::NoPen);
        for(Star &s : stars){
            s.y += s.speedY;
            if(s.y>height()) s.y=0;
            int alpha = QRandomGenerator::global()->bounded(100,255);
            painter.setBrush(QColor(255,255,255,alpha));
            painter.drawEllipse(s.x,s.y,s.radius,s.radius);
        }

        // 标题文字 “羊羊大作战”
        QString title = "羊羊大作战";
        int startX = 70;
        int startY = 150;
        int fontSize = 60;

        painter.setFont(QFont("Arial", fontSize, QFont::Bold));

        for(int i=0; i<title.size(); i++){
            QString ch = title.mid(i,1);

            // 先画蓝色描边
            QPen pen(Qt::blue);
            pen.setWidth(4);  // 描边粗细
            painter.setPen(pen);
            painter.setBrush(Qt::NoBrush);
            painter.drawText(startX + i*fontSize*1.5, startY, ch);

            // 再画白色填充
            painter.setPen(Qt::NoPen);
            painter.setBrush(Qt::white);
            painter.drawText(startX + i*fontSize*1.5, startY, ch);
        }

        // 开始按钮浮动动画
        static int t=0; t++;
        int floatY = 550 + static_cast<int>(5*sin(t*0.1));
        if(startButton->isVisible()) startButton->move(350,floatY);

        update();
        return;
    }

    // ---------------- 游戏背景 ----------------
    QLinearGradient gradient(0,0,0,height());
    gradient.setColorAt(0,QColor(5,5,50));
    gradient.setColorAt(1,QColor(0,0,20));
    painter.fillRect(rect(),gradient);

    // 星星
    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::white);
    for(const Star &s:stars){
        int sx=s.x-offsetX;
        int sy=s.y-offsetY;
        if(sx>=0 && sx<=width() && sy>=0 && sy<=height()) painter.drawEllipse(sx,sy,s.radius,s.radius);
    }

    // 道具
    for(const Item &it:items){
        int ix=it.x-offsetX; int iy=it.y-offsetY;
        if(ix>=0 && ix<=width() && iy>=0 && iy<=height()){
            switch(it.type){
                case Item::Speed:painter.setBrush(Qt::green);break;
                case Item::Shield:painter.setBrush(Qt::yellow);break;
                case Item::Heal:painter.setBrush(Qt::red);break;
            }
            painter.drawEllipse(ix-it.radius,iy-it.radius,it.radius*2,it.radius*2);
        }
    }

    // 食物
    for(const Ball &f:foods){
        int fx=f.x-offsetX; int fy=f.y-offsetY;
        if(fx>=0 && fx<=width() && fy>=0 && fy<=height()){
            QColor c=f.color;c.setAlpha(QRandomGenerator::global()->bounded(150,255));
            painter.setBrush(c);
            painter.drawEllipse(fx-f.radius,fy-f.radius,f.radius*2,f.radius*2);
        }
    }

    // ---------------- 敌人球绘制（圆形皮肤） ----------------
    for(const Ball &e:enemies){
        int ex=e.x-offsetX;
        int ey=e.y-offsetY;
        int drawRadius = e.radius;
        if(drawRadius < 10) drawRadius = 10; // 最小半径保证可见

        if(!e.skin.isNull()){
            QPixmap scaledSkin = e.skin.scaled(drawRadius*2, drawRadius*2,
                                               Qt::KeepAspectRatioByExpanding,
                                               Qt::SmoothTransformation);
            QPainterPath path;
            path.addEllipse(ex - drawRadius, ey - drawRadius, drawRadius*2, drawRadius*2);
            painter.setClipPath(path);
            painter.drawPixmap(ex - drawRadius, ey - drawRadius, drawRadius*2, drawRadius*2, scaledSkin);
            painter.setClipping(false);
        } else {
            painter.setBrush(e.color);
            painter.setPen(Qt::NoPen);
            painter.drawEllipse(ex - drawRadius, ey - drawRadius, drawRadius*2, drawRadius*2);
        }
    }

    // ---------------- 玩家球绘制（圆形皮肤） ----------------
    int viewX = player.x - offsetX;
    int viewY = player.y - offsetY;
    int drawRadius = player.radius;
    if(drawRadius < 20) drawRadius = 20; // 最小半径保证可见

    if(!player.skin.isNull()){
        QPixmap scaledSkin = player.skin.scaled(drawRadius*2, drawRadius*2,
                                                Qt::KeepAspectRatioByExpanding,
                                                Qt::SmoothTransformation);
        QPainterPath path;
        path.addEllipse(viewX - drawRadius, viewY - drawRadius, drawRadius*2, drawRadius*2);
        painter.setClipPath(path);
        painter.drawPixmap(viewX - drawRadius, viewY - drawRadius, drawRadius*2, drawRadius*2, scaledSkin);
        painter.setClipping(false);
    } else {
        QRadialGradient glow(viewX, viewY, drawRadius + 10, viewX, viewY);
        glow.setColorAt(0, player.color.lighter(120));
        glow.setColorAt(1, player.color.darker(150));
        painter.setBrush(glow);
        painter.setPen(Qt::NoPen);
        painter.drawEllipse(viewX - drawRadius, viewY - drawRadius, drawRadius*2, drawRadius*2);
    }

    // ---------------- 时间 / 分数 / 血条 ----------------
    painter.setPen(Qt::white);
    painter.setFont(QFont("Arial",20,QFont::Bold));
    int minTime = remainingTime/60;
    int secTime = remainingTime%60;
    painter.drawText(width()/2-50,40,QString("时间 %1:%2").arg(minTime).arg(secTime,2,10,QChar('0')));

    painter.setFont(QFont("Arial",16));
    painter.drawText(10,70,QString("Score: %1").arg(score));

    painter.setBrush(Qt::red);
    painter.drawRect(10,100,hp*2,10);
}

// ---------------- 鼠标控制 ----------------
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if(!inGame) return;
    int mouseX = event->x() + offsetX;
    int mouseY = event->y() + offsetY;
    int dx = mouseX - player.x;
    int dy = mouseY - player.y;
    float dist = std::sqrt(dx*dx + dy*dy);
    float step = 3.5;
    if(dist>step){
        player.x += dx/dist*step;
        player.y += dy/dist*step;
    } else {
        player.x = mouseX;
        player.y = mouseY;
    }

    if(player.x<player.radius) player.x=player.radius;
    if(player.x>MAP_WIDTH-player.radius) player.x=MAP_WIDTH-player.radius;
    if(player.y<player.radius) player.y=player.radius;
    if(player.y>MAP_HEIGHT-player.radius) player.y=MAP_HEIGHT-player.radius;

    offsetX = player.x-width()/2;
    offsetY = player.y-height()/2;
    if(offsetX<0) offsetX=0;
    if(offsetY<0) offsetY=0;
    if(offsetX>MAP_WIDTH-width()) offsetX=MAP_WIDTH-width();
    if(offsetY>MAP_HEIGHT-height()) offsetY=MAP_HEIGHT-height();
}

// ---------------- spawnStars ----------------
void MainWindow::spawnStars()
{
    stars.clear();
    for(int i=0;i<150;i++){
        Star s;
        s.x = QRandomGenerator::global()->bounded(MAP_WIDTH);
        s.y = QRandomGenerator::global()->bounded(MAP_HEIGHT);
        s.radius = 1 + QRandomGenerator::global()->bounded(2);
        s.speedY = 1 + QRandomGenerator::global()->bounded(2);
        stars.push_back(s);
    }
}

// ---------------- moveStars ----------------
void MainWindow::moveStars()
{
    for(Star &s: stars){
        s.y += s.speedY;
        if(s.y > MAP_HEIGHT) s.y = 0;
    }
}

// ---------------- 初始化游戏 ----------------
void MainWindow::initGame()
{
    player.x = MAP_WIDTH/2;
    player.y = MAP_HEIGHT/2;
    player.radius = 20;
    player.hp = MAX_HP;
    hp = MAX_HP;
    score = 50;
    remainingTime = GAME_DURATION;

    offsetX = player.x - width()/2;
    offsetY = player.y - height()/2;

    foods.clear(); spawnFood(150);
    enemies.clear(); spawnEnemies(20);
    items.clear(); spawnItems();
}

// ---------------- spawnFood ----------------
void MainWindow::spawnFood(int count)
{
    int sizes[3] = {5,8,12};
    for(int i=0;i<count;i++){
        Ball f;
        f.x = QRandomGenerator::global()->bounded(20, MAP_WIDTH-20);
        f.y = QRandomGenerator::global()->bounded(20, MAP_HEIGHT-20);
        f.radius = sizes[QRandomGenerator::global()->bounded(3)];
        f.color = QColor::fromRgb(QRandomGenerator::global()->bounded(255),
                                  QRandomGenerator::global()->bounded(255),
                                  QRandomGenerator::global()->bounded(255));
        f.hp = 0;
        foods.push_back(f);
    }
}

// ---------------- spawnEnemies ----------------
void MainWindow::spawnEnemies(int count)
{
    QStringList enemySkins = allSkins;
    if(playerSkinIndex>=0) enemySkins.removeAt(playerSkinIndex);

    for(int i=0;i<count;i++){
        Ball e;
        e.x = QRandomGenerator::global()->bounded(20, MAP_WIDTH-20);
        e.y = QRandomGenerator::global()->bounded(20, MAP_HEIGHT-20);
        e.radius = 10 + QRandomGenerator::global()->bounded(10,50);
        e.speedX = QRandomGenerator::global()->bounded(-3,4);
        e.speedY = QRandomGenerator::global()->bounded(-3,4);
        e.hp = 100;
        int idx = QRandomGenerator::global()->bounded(enemySkins.size());
        e.skin = QPixmap(enemySkins[idx]).scaled(
                    e.radius*2,e.radius*2,Qt::KeepAspectRatio,Qt::SmoothTransformation);
        enemies.push_back(e);
    }
}

// ---------------- spawnItems ----------------
void MainWindow::spawnItems()
{
    for(int i=0;i<10;i++){
        Item it;
        it.x = QRandomGenerator::global()->bounded(50, MAP_WIDTH-50);
        it.y = QRandomGenerator::global()->bounded(50, MAP_HEIGHT-50);
        it.radius = 10;
        int t = QRandomGenerator::global()->bounded(3);
        it.type = static_cast<Item::Type>(t);
        items.push_back(it);
    }
}

// ---------------- gameUpdate ----------------
void MainWindow::gameUpdate()
{
    if(!inGame) return;

    // 移动敌人
    for(Ball &e : enemies){
        e.x += e.speedX;
        e.y += e.speedY;
        if(e.x<e.radius || e.x>MAP_WIDTH-e.radius) e.speedX=-e.speedX;
        if(e.y<e.radius || e.y>MAP_HEIGHT-e.radius) e.speedY=-e.speedY;
    }

    // 移动星星
    moveStars();

    // 检查碰撞
    checkCollisions();

    update();
}

// ---------------- updateTimer ----------------
void MainWindow::updateTimer()
{
    if(!inGame) return;
    remainingTime--;
    if(remainingTime<=0) gameOver(false);
}

// ---------------- checkCollisions ----------------
void MainWindow::checkCollisions()
{
    // 玩家吃食物
    // 玩家吃食物逻辑
    for(int i = foods.size() - 1; i >= 0; i--){
        Ball f = foods[i];
        float dx = player.x - f.x;
        float dy = player.y - f.y;
        float dist = std::sqrt(dx*dx + dy*dy);

        if(dist < player.radius + f.radius){
            // 玩家吃掉小球
            score += f.radius * 2;
            player.radius += f.radius * 0.2;

            // 删除原小球
            foods.remove(i);

            // 生成一个新小球到随机位置
            Ball newFood;
            newFood.x = QRandomGenerator::global()->bounded(20, MAP_WIDTH-20);
            newFood.y = QRandomGenerator::global()->bounded(20, MAP_HEIGHT-20);
            int sizes[3] = {5,8,12};
            newFood.radius = sizes[QRandomGenerator::global()->bounded(3)];
            newFood.color = QColor::fromRgb(
                QRandomGenerator::global()->bounded(255),
                QRandomGenerator::global()->bounded(255),
                QRandomGenerator::global()->bounded(255)
            );

            foods.push_back(newFood);
        }
    }

    // 玩家吃道具
    for(int i=items.size()-1;i>=0;i--){
        Item &it = items[i];
        float dx = player.x - it.x;
        float dy = player.y - it.y;
        float dist = std::sqrt(dx*dx + dy*dy);
        if(dist < player.radius + it.radius){
            applyItemEffect(it.type);
            items.remove(i);
        }
    }

    // 玩家碰敌人
    for(int i=enemies.size()-1;i>=0;i--){
        Ball &e = enemies[i];
        float dx = player.x - e.x;
        float dy = player.y - e.y;
        float dist = std::sqrt(dx*dx + dy*dy);
        if(dist < player.radius + e.radius){
            if(player.radius > e.radius){
                // 玩家吃掉敌人
                player.radius += e.radius*0.2;
                score += e.radius*2;
                enemies.remove(i);
            } else {
                // 玩家被敌人碰撞，逐渐减小
                player.radius -= 0.2;
                score -= 1;
                if(score<=0 || player.radius<10) gameOver(false);
            }
        }
    }

    // 敌人吃食物
    for(Ball &e: enemies){
        for(int i=foods.size()-1;i>=0;i--){
            Ball &f = foods[i];
            float dx = e.x - f.x;
            float dy = e.y - f.y;
            float dist = std::sqrt(dx*dx + dy*dy);
            if(dist < e.radius + f.radius){
                e.radius += f.radius*0.2;
                foods.remove(i);
            }
        }
    }
}

// ---------------- applyItemEffect ----------------
void MainWindow::applyItemEffect(Item::Type type)
{
    switch(type){
        case Item::Speed: break; // 可以增加玩家移动速度
        case Item::Shield: break; // 可以暂时增加无敌
        case Item::Heal:
            player.radius += 5;
            score +=10;
            break;
    }
}

// ---------------- gameOver ----------------
void MainWindow::gameOver(bool win)
{
    Q_UNUSED(win); // 消除未使用参数警告

    inGame = false;
    countdownTimer->stop();

    QString msg;
    if(win){
        msg = QString("你获胜了！\n本次得分: %1\n球大小: %2").arg(score).arg(player.radius);
    } else {
        msg = QString("游戏结束！\n本次得分: %1\n球大小: %2").arg(score).arg(player.radius);
    }

    QMessageBox::information(this, "游戏结束", msg);

    // 重置游戏
    foods.clear();
    enemies.clear();
    items.clear();
    player.radius = 20;
    score = 50;
    remainingTime = GAME_DURATION;
    offsetX = player.x - width()/2;
    offsetY = player.y - height()/2;

    // 显示开机界面按钮
    for(QPushButton* b: skinButtons) b->show();
    startButton->hide();
}
