#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QRandomGenerator>
#include <cmath>
#include <QFont>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(900,700);
    inGame = false;

    this->setMouseTracking(true); // 鼠标拖动控制玩家

    startButton = new QPushButton("开始游戏", this);
    startButton->setGeometry(350, 550, 200, 100);
    startButton->setStyleSheet("font-size:24px; background-color: #00AAFF; color: white; border-radius: 10px;");
    connect(startButton, &QPushButton::clicked, this, &MainWindow::startGame);
    startButton->setFocusPolicy(Qt::NoFocus);

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::gameUpdate);
    timer->start(30);

    countdownTimer = new QTimer(this);
    connect(countdownTimer, &QTimer::timeout, this, &MainWindow::updateTimer);

    spawnStars();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ---------------- 星星 ----------------
void MainWindow::spawnStars()
{
    stars.clear();
    for(int i=0;i<150;i++){
        Star s;
        s.x = QRandomGenerator::global()->bounded(MAP_WIDTH);
        s.y = QRandomGenerator::global()->bounded(MAP_HEIGHT);
        s.radius = 1 + QRandomGenerator::global()->bounded(2);
        s.speedY = 1 + QRandomGenerator::global()->bounded(2);
        stars.push_back(s);
    }
}

void MainWindow::moveStars()
{
    for(Star &s : stars){
        s.y += s.speedY;
        if(s.y > MAP_HEIGHT) s.y = 0;
    }
}

// ---------------- 游戏开始 ----------------
void MainWindow::startGame()
{
    startButton->hide();
    inGame = true;
    this->setFocusPolicy(Qt::StrongFocus);
    this->setFocus();
    initGame();
    countdownTimer->start(1000);
}

void MainWindow::initGame()
{
    player.x = MAP_WIDTH/2;
    player.y = MAP_HEIGHT/2;
    player.radius = 20;
    player.color = QColor::fromRgb(0,200,255);
    player.hp = MAX_HP;
    hp = MAX_HP;

    offsetX = player.x - width()/2;
    offsetY = player.y - height()/2;

    score = 50; // 初始分数
    remainingTime = GAME_DURATION;

    foods.clear(); spawnFood(150);
    enemies.clear(); spawnEnemies(20);
    items.clear();
    for(int i=0;i<10;i++) spawnItems();
}

// ---------------- 食物/敌人/道具 ----------------
void MainWindow::spawnFood(int count)
{
    int sizes[3] = {5,8,12};
    for(int i=0;i<count;i++){
        Ball f;
        f.x = QRandomGenerator::global()->bounded(20, MAP_WIDTH-20);
        f.y = QRandomGenerator::global()->bounded(20, MAP_HEIGHT-20);
        f.radius = sizes[QRandomGenerator::global()->bounded(3)];
        f.color = QColor::fromRgb(QRandomGenerator::global()->bounded(255),
                                  QRandomGenerator::global()->bounded(255),
                                  QRandomGenerator::global()->bounded(255));
        f.hp = 0;
        foods.push_back(f);
    }
}

void MainWindow::spawnEnemies(int count)
{
    for(int i=0;i<count;i++){
        Ball e;
        e.x = QRandomGenerator::global()->bounded(20, MAP_WIDTH-20);
        e.y = QRandomGenerator::global()->bounded(20, MAP_HEIGHT-20);
        e.radius = 10 + QRandomGenerator::global()->bounded(10, 50);
        e.color = QColor::fromRgb(QRandomGenerator::global()->bounded(255),
                                  QRandomGenerator::global()->bounded(255),
                                  QRandomGenerator::global()->bounded(255));
        e.speedX = QRandomGenerator::global()->bounded(-3,4);
        e.speedY = QRandomGenerator::global()->bounded(-3,4);
        e.hp = 100;
        enemies.push_back(e);
    }
}

void MainWindow::spawnItems()
{
    Item it;
    it.x = QRandomGenerator::global()->bounded(50, MAP_WIDTH-50);
    it.y = QRandomGenerator::global()->bounded(50, MAP_HEIGHT-50);
    it.radius = 10;
    int t = QRandomGenerator::global()->bounded(3);
    it.type = static_cast<Item::Type>(t);
    items.push_back(it);
}

// ---------------- 绘制 ----------------
void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QLinearGradient gradient(0,0,0,height());
    gradient.setColorAt(0, QColor(5,5,50));
    gradient.setColorAt(1, QColor(0,0,20));
    painter.fillRect(rect(), gradient);

    painter.setBrush(Qt::white);
    painter.setPen(Qt::NoPen);
    for(const Star &s : stars){
        int sx = s.x - offsetX;
        int sy = s.y - offsetY;
        if(sx>=0 && sx<=width() && sy>=0 && sy<=height())
            painter.drawEllipse(sx, sy, s.radius, s.radius);
    }

    for(const Item &it: items){
        int ix = it.x - offsetX;
        int iy = it.y - offsetY;
        if(ix>=0 && ix<=width() && iy>=0 && iy<=height()){
            switch(it.type){
                case Item::Speed: painter.setBrush(Qt::green); break;
                case Item::Shield: painter.setBrush(Qt::yellow); break;
                case Item::Heal: painter.setBrush(Qt::red); break;
            }
            painter.drawEllipse(ix-it.radius, iy-it.radius, it.radius*2, it.radius*2);
        }
    }

    for(const Ball &f : foods){
        int fx = f.x - offsetX;
        int fy = f.y - offsetY;
        if(fx>=0 && fx<=width() && fy>=0 && fy<=height()){
            QColor c = f.color;
            c.setAlpha(QRandomGenerator::global()->bounded(150,255));
            painter.setBrush(c);
            painter.drawEllipse(fx - f.radius, fy - f.radius, f.radius*2, f.radius*2);
        }
    }

    for(const Ball &e : enemies){
        int ex = e.x - offsetX;
        int ey = e.y - offsetY;
        if(ex>=0 && ex<=width() && ey>=0 && ey<=height()){
            painter.setBrush(e.color);
            painter.drawEllipse(ex - e.radius, ey - e.radius, e.radius*2, e.radius*2);
        }
    }

    int viewX = player.x - offsetX;
    int viewY = player.y - offsetY;
    QRadialGradient glow(viewX, viewY, player.radius+10, viewX, viewY);
    glow.setColorAt(0, player.color.lighter(120));
    glow.setColorAt(1, player.color.darker(150));
    painter.setBrush(glow);
    painter.drawEllipse(viewX - player.radius, viewY - player.radius, player.radius*2, player.radius*2);

    painter.setPen(Qt::white);
    painter.setFont(QFont("Arial", 20, QFont::Bold));
    int min = remainingTime/60;
    int sec = remainingTime%60;
    painter.drawText(width()/2-50, 40, QString("时间 %1:%2").arg(min).arg(sec,2,10,QChar('0')));

    painter.setFont(QFont("Arial",16));
    painter.drawText(10,70, QString("Score: %1").arg(score));
    painter.setBrush(Qt::red);
    painter.drawRect(10,100, hp*2,10);
}

// ---------------- 鼠标拖动 ----------------
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if(!inGame) return;

    int mouseX = event->x() + offsetX;
    int mouseY = event->y() + offsetY;

    int dx = mouseX - player.x;
    int dy = mouseY - player.y;

    float dist = std::sqrt(dx*dx + dy*dy);
    float step = 2.2;
    if(dist > step) {
        player.x += dx / dist * step;
        player.y += dy / dist * step;
    } else {
        player.x = mouseX;
        player.y = mouseY;
    }

    if(player.x < player.radius) player.x = player.radius;
    if(player.x > MAP_WIDTH - player.radius) player.x = MAP_WIDTH - player.radius;
    if(player.y < player.radius) player.y = player.radius;
    if(player.y > MAP_HEIGHT - player.radius) player.y = MAP_HEIGHT - player.radius;

    offsetX = player.x - width()/2;
    offsetY = player.y - height()/2;
    if(offsetX < 0) offsetX = 0;
    if(offsetY < 0) offsetY = 0;
    if(offsetX > MAP_WIDTH - width()) offsetX = MAP_WIDTH - width();
    if(offsetY > MAP_HEIGHT - height()) offsetY = MAP_HEIGHT - height();
}

// ---------------- 每帧更新 ----------------
void MainWindow::gameUpdate()
{
    if(!inGame) return;
    static int spawnCounter = 0;
    spawnCounter++;
    if(spawnCounter >= 30){
        if(enemies.size() < 20) spawnEnemies(1);
        spawnCounter = 0;
    }
    moveEnemies();
    moveStars();
    checkCollisions();
    update();
}

// ---------------- 倒计时 ----------------
void MainWindow::updateTimer()
{
    if(!inGame) return;
    remainingTime--;
    if(remainingTime <= 0) gameOver(false);
}

// ---------------- 敌人逻辑 ----------------
void MainWindow::moveEnemies()
{
    for(Ball &e : enemies){
        e.x += e.speedX;
        e.y += e.speedY;
        if(e.x<e.radius||e.x>MAP_WIDTH-e.radius) e.speedX*=-1;
        if(e.y<e.radius||e.y>MAP_HEIGHT-e.radius) e.speedY*=-1;

        for(int i=foods.size()-1;i>=0;i--){
            Ball &f = foods[i];
            int dx = e.x-f.x; int dy = e.y-f.y;
            if(std::sqrt(dx*dx+dy*dy)<e.radius+f.radius){
                e.radius += f.radius/8;
                foods.remove(i);
                spawnFood(1);
            }
        }

        for(int i=0;i<enemies.size();i++){
            Ball &e2 = enemies[i];
            if(&e==&e2) continue;
            int dx = e.x-e2.x; int dy = e.y-e2.y;
            if(std::sqrt(dx*dx+dy*dy)<e.radius+e2.radius){
                if(e.radius>=e2.radius){
                    e.radius += e2.radius/8;
                    e2.radius=0;
                }
            }
        }

        int dx = player.x-e.x;
        int dy = player.y-e.y;
        float dist = std::sqrt(dx*dx + dy*dy);
        if(dist < player.radius+e.radius){
            if(player.radius >= e.radius){
                player.radius += e.radius/8;
                score +=5;
                e.radius=0;
            } else {
                player.radius -= 0.1;
                score -= 1;
                if(score <=0) gameOver(false);
            }
        }
    }

    for(int i=enemies.size()-1;i>=0;i--) if(enemies[i].radius<=0) enemies.remove(i);
}

// ---------------- 玩家吃球 + 道具 ----------------
void MainWindow::checkCollisions()
{
    for(int i=foods.size()-1;i>=0;i--){
        Ball &f = foods[i];
        int dx=player.x-f.x, dy=player.y-f.y;
        if(std::sqrt(dx*dx+dy*dy)<player.radius+f.radius){
            player.radius += f.radius/8;
            score++;
            foods.remove(i);
            spawnFood(1);
        }
    }
    for(int i=items.size()-1;i>=0;i--){
        Item &it = items[i];
        int dx=player.x-it.x, dy=player.y-it.y;
        if(std::sqrt(dx*dx+dy*dy)<player.radius+it.radius){
            applyItemEffect(it.type);
            items.remove(i);
        }
    }
}

// ---------------- 道具效果 ----------------
void MainWindow::applyItemEffect(Item::Type type)
{
    switch(type){
        case Item::Speed: break;
        case Item::Shield: break;
        case Item::Heal: hp +=20; if(hp>MAX_HP) hp=MAX_HP; break;
    }
}

// ---------------- 游戏结束 ----------------
void MainWindow::gameOver(bool win)
{
    inGame=false;
    QString msg=QString("%1\n球半径:%2\n得分:%3")
                .arg(win?"胜利！":"失败！")
                .arg(player.radius)
                .arg(score);
    QMessageBox::information(this,"游戏结束",msg);

    player.radius=20;
    hp=MAX_HP;
    startButton->setText("重新开始");
    startButton->show();
    enemies.clear();
    foods.clear();
    items.clear();
    spawnStars();
}
