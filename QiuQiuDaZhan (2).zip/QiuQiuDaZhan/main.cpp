#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.setStyle("Fusion");  // 可选，界面更现代

    MainWindow w;
    w.show();

    return a.exec();
}
